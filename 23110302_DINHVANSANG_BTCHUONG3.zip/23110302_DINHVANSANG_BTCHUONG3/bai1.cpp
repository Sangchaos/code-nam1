// MSSV: 23110302 
// Ho và tên : Đinh Van Sáng  
// 04/03/2005  

#include<iostream>
#include <cmath>
using namespace std ;

int main() {
    int x, p ;
    cin>>x>>p;
    cout<<pow(x, p) ;
}